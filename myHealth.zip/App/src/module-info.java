module App {
	requires javafx.controls;
	requires javafx.fxml;
	requires javafx.graphics;
	requires java.sql;
	requires org.xerial.sqlitejdbc;
	requires javafx.base;
	requires java.desktop;
	requires junit;
	requires org.junit.jupiter.api;
	
	
	opens application to javafx.graphics, javafx.fxml, javafx.base, src.tests;


}
