package application;

/**
 * Class defines user details for post login use
 * 
 * @author s3805554
 *
 */
public class User {

	/**
	 * initialise static variables
	 */
	private static String firstname;
	private static String lastname;
	private static String username;

	/**
	 * method gets users first name
	 * 
	 * @return firstname
	 */
	public static String getFirstname() {
		return firstname;
	}

	/**
	 * method sets users last name
	 * 
	 * @param lastname
	 */
	public static void setFirstname(String firstname) {
		User.firstname = firstname;
	}

	/**
	 * method gets users last name
	 * 
	 * @return lastname
	 */
	public static String getLastname() {
		return lastname;
	}

	/**
	 * method sets users last name
	 * 
	 * @param lasstname
	 */
	public static void setLastname(String lastname) {
		User.lastname = lastname;
	}

	/**
	 * method gets username
	 * 
	 * @return username
	 */
	public static String getUsername() {
		return username;
	}

	/**
	 * method sets username
	 * 
	 * @param username
	 */
	public static void setUsername(String username) {
		User.username = username;
	}

}
