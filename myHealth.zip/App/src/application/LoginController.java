package application;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class LoginController {

	@FXML
	private Label message; // user message
	@FXML
	private TextField firstname; // user input
	@FXML
	private TextField lastname; // user input
	@FXML
	private TextField username; // user input
	@FXML
	private PasswordField password; // user input
	@FXML
	private PasswordField password2; // only used on password reset
	@FXML
	private Button loginbutton; // login to myhealth
	@FXML
	private Hyperlink forgotpassword; // new scene link
	@FXML
	private Hyperlink register; // new scene link

	// class instance declarations
	DBController db = new DBController(); // database control class
	User user = new User(); // user class

	/**
	 * load scene on action request
	 * 
	 * @param event: javafx action event
	 * @throws IOException: file not found error
	 */
	@FXML
	private void loginScene(ActionEvent event) throws IOException {
		Main.setRoot("fxml/login"); // load scene
	}

	/**
	 * load scene on action request
	 * 
	 * @param event: javafx action event
	 * @throws IOException: file not found error
	 */
	@FXML
	private void registerScene(ActionEvent event) throws IOException {
		Main.setRoot("fxml/login-user-register"); // load scene
	}

	/**
	 * load scene on action request
	 * 
	 * @param event: javafx action event
	 * @throws IOException: file not found error
	 */
	@FXML
	private void resetScene(ActionEvent event) throws IOException {
		Main.setRoot("fxml/login-password-reset"); // load scene
	}

	/**
	 * load scene on action request
	 * 
	 * @param event: javafx action event
	 * @throws IOException:              file not found error
	 * @throws SQLException:             database access error
	 * @throws NoSuchAlgorithmException: hash method error
	 */
	@FXML
	private void login(ActionEvent event) throws IOException, NoSuchAlgorithmException, SQLException {

		// if database record matched entered data
		if (db.login(username.getText(), hashPassword(password.getText()))) {
			User.setUsername(username.getText()); // assign textfield information to User class
			Main.setRoot("fxml/main"); // load scene
		} else {
			message.setText("LOGIN DETAILS INCORRECT"); // display user error message
			message.setTextFill(javafx.scene.paint.Color.RED); // color user message
		}
	}

	/**
	 * method takes user input passwrod and converts to hashed string
	 * 
	 * @param password: raw password
	 * @return hashed password string
	 * @throws NoSuchAlgorithmException: message digest error
	 */
	private String hashPassword(String password) throws NoSuchAlgorithmException {

		MessageDigest msg = MessageDigest.getInstance("SHA-256"); // initialize method
		msg.update(password.getBytes()); // convert password to bytes and add to message digest
		byte[] digest = msg.digest(); // perform padding operations

		StringBuffer sb = new StringBuffer(); // reconstruct method initialization
		for (byte b : digest) { // loop through digest list
			sb.append(String.format("%02x", b & 0xff)); // convert to a hex value
		}
		return String.valueOf(sb); // returned hashed string
	}

	/**
	 * register new user action request
	 * 
	 * @param event: javafx action event
	 * @throws IOException:              file not found error
	 * @throws SQLException:             database access error
	 * @throws NoSuchAlgorithmException: hash method error
	 */
	@FXML
	private void registerUser(ActionEvent event) throws IOException, NoSuchAlgorithmException, SQLException {

		// if details filled in
		if (!firstname.getText().isEmpty() && !lastname.getText().isEmpty() && !username.getText().isEmpty()
				&& !password.getText().isEmpty()) {

			// check username is 5 characters minimum and passowrd is 8 characters minimum
			if (username.getText().length() >= 5 && password.getText().length() >= 8) {

				// call database method adding a new user to databae
				if (db.registerUser(firstname.getText(), lastname.getText(), username.getText(),
						hashPassword(password.getText()))) {

					User.setUsername(username.getText()); // assign user name to user class instance
					Main.setRoot("fxml/main"); // load main application scene

				} else { // username has been used
					message.setText("USERNAME TAKEN"); // send user message
					message.setTextFill(javafx.scene.paint.Color.RED); // color message red
				}

			} else { // details not minimum size

				// password is to small
				if (username.getText().length() >= 5 && password.getText().length() < 8) {
					message.setText("PASSWORD MUST BE 8 CHARACTERS OF MORE"); // send user message
					message.setTextFill(javafx.scene.paint.Color.RED); // color message red

					// username is to small
				} else if (username.getText().length() < 5 && password.getText().length() >= 8) {
					message.setText("USERNAME MUST BE 5 CHARACTERS OF MORE"); // send user message
					message.setTextFill(javafx.scene.paint.Color.RED); // color message red

					// both username and password are to small
				} else {
					message.setText("USERNAME AND PASSWORD TO SHORT"); // send user message
					message.setTextFill(javafx.scene.paint.Color.RED); // color message red
				}
			}

		} else { // no details have been filled in
			message.setText("PLEASE FILL IN A DETAILS"); // send user message
			message.setTextFill(javafx.scene.paint.Color.RED); // color message red
		}

	}

	/**
	 * method resets password for user
	 * 
	 * @param event: javafx action event
	 * @throws IOException:  file not found error
	 * @throws SQLException: database access error
	 */
	@FXML
	private void resetPassword(ActionEvent event) throws IOException, SQLException {

		// checks if details match in database
		if (db.resetPassword(firstname.getText(), lastname.getText(), username.getText())) {

			User.setUsername(username.getText()); // sets and instance of user class - user name
			Main.setRoot("fxml/login-password-update"); // load scene

		} else {
			message.setText("DETAILS NOT FOUND"); // send user message
			message.setTextFill(javafx.scene.paint.Color.RED); // color message red
		}
	}

	/**
	 * register new user action request
	 * 
	 * @param event: javafx action event
	 * @throws IOException:              file not found error
	 * @throws SQLException:             database access error
	 * @throws NoSuchAlgorithmException: hash method error
	 */
	@FXML
	private void updatePassword(ActionEvent event) throws SQLException, NoSuchAlgorithmException, IOException {

		// test if password lengths is 8 or more characters
		if (password.getText().length() < 8 && password.getText().length() < 8) {
			message.setText("PASSWORD MUST BE 8 OR MORE"); // send user message
			message.setTextFill(javafx.scene.paint.Color.RED); // color message red

		} else {

			// check passwords are a matched pair
			if (hashPassword((password.getText())).equals(hashPassword((password2.getText())))) {

				// check if password is same as database
				if (db.passwordExists(hashPassword((password.getText())))) {
					message.setText("PLEASE USE A NEW PASSWORD"); // send user message
					message.setTextFill(javafx.scene.paint.Color.RED); // color message red

				} else { // passwords ok update database with hashed password
					db.changePassword(User.getUsername(), hashPassword((password.getText())));
					Main.setRoot("fxml/login"); // load scene
				}

			} else { // send user message as passwords are different
				message.setText("PASSWORD DO NOT MATCH"); // send user message
				message.setTextFill(javafx.scene.paint.Color.RED); // color message red
			}
		}
	}
}
