package application;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import javafx.collections.ObservableList;

/**
 * 
 * database controller qeuries anbd accesses database
 * 
 * @author s3805554
 */
public class DBController {

	// declare instance variables
	private Connection connection = null; // database connection
	private PreparedStatement statement = null; // database query statement
	private ResultSet resultset = null; // database query result

	/**
	 * method gets a connection to the database
	 * 
	 * @return connection: database connection
	 * @throws SQLException: database access error
	 */
	public Connection connect() throws SQLException {
		try {
			connection = DriverManager.getConnection("jdbc:sqlite:myhealth.db"); // get databas econnection
		} catch (Exception e) {
			System.out.println("Database access error, check database connection");
		}
		return connection; // return database connection upon success
	}

	/**
	 * method queries login details in database
	 * 
	 * @param username: entered user name
	 * @param password: encrypted password
	 * @return boolean: true / false
	 * @throws SQLException: database access error
	 */
	public boolean login(String username, String password) throws SQLException {

		Connection connection = connect(); // get database connection

		if (connection != null) { // database connection established

			String sql = "SELECT password FROM accounts WHERE username=?"; // set qeury string

			statement = connection.prepareStatement(sql); // set precompiled sql string
			statement.setString(1, username); // assign parameter to sql string
			resultset = statement.executeQuery(); // execute database query and store result

			while (resultset.next()) {
				if (password.equals(resultset.getString("password"))) {
					connection.close(); // close connection
					statement.close(); // close prepared statement
					resultset.close(); // close result set
					return true; // database query completed
				}
			}
		}
		connection.close(); // close connection
		statement.close(); // close prepared statement
		resultset.close(); // close result set
		return false; // database query not completed
	}

	/**
	 * method registerUser calls usernameExists, if usernameExists returns false
	 * registers user details in database
	 * 
	 * @param firstname: users first name
	 * @param lastname:  users surname
	 * @param username:  entered user name
	 * @param password:  encrypted password
	 * @return boolean value: true / false
	 * @throws SQLException: database access error
	 */
	public boolean registerUser(String firstname, String lastname, String username, String password)
			throws SQLException {

		if (!usernameExists(username)) {
			String sql = "INSERT INTO accounts (username, password, firstname, lastname, picture)VALUES(?,?,?,?,null)"; // set
																														// qeury
																														// string

			Connection connection = connect(); // get database connection

			PreparedStatement statement = connection.prepareStatement(sql); // set precompiled sql string
			statement.setString(1, username); // assign parameter to sql string
			statement.setString(2, password); // assign parameter to sql string
			statement.setString(3, firstname); // assign parameter to sql string
			statement.setString(4, lastname); // assign parameter to sql string
			statement.executeUpdate(); // execute sql statement

			connection.close(); // close connection
			statement.close(); // close prepared statement
			return true; // database query completed
		}
		connection.close(); // close connection
		statement.close(); // close prepared statement
		return false; // database query not completed
	}

	/**
	 * method usernameExists checks user requested name against database
	 * 
	 * @param username: entered user name
	 * @return boolean: true / false
	 * @throws SQLException: database access error
	 */
	public boolean usernameExists(String username) throws SQLException {

		Connection connection = connect(); // get database connection

		if (connection != null) { // database connection established

			String sql = "SELECT username FROM accounts WHERE username=?"; // set qeury string

			statement = connection.prepareStatement(sql); // set precompiled sql string
			statement.setString(1, username); // assign parameter to sql string
			resultset = statement.executeQuery(); // execute sql statement

			// loop through resultset
			while (resultset.next()) {

				// check if username is in database
				if (username.equals(resultset.getString("username"))) {
					connection.close(); // close connection
					statement.close(); // close prepared statement
					resultset.close(); // close result set
					return true; // database query completed
				}
			}
		}
		connection.close(); // close connection
		statement.close(); // close prepared statement
		resultset.close(); // close result set
		return false; // database query not completed
	}

	/**
	 * method resetPassword checks all entered details against database
	 * 
	 * @param lastname: users surname
	 * @param username: entered user name
	 * @param password: encrypted password
	 * @return boolean: true / false
	 * @throws SQLException: database access error
	 */
	public boolean resetPassword(String firstname, String lastname, String username) throws SQLException {

		Connection connection = connect(); // get database connection

		if (connection != null) { // database connection established

			String sql = "SELECT username, firstname, lastname FROM accounts WHERE username=?"; // set qeury string

			statement = connection.prepareStatement(sql); // set precompiled sql string
			statement.setString(1, username); // assign parameter to sql string
			resultset = statement.executeQuery(); // execute sql statement

			// loop through resultset
			while (resultset.next()) {

				String dbfirstname = resultset.getString("firstname").toLowerCase(); // assign result to string
				String dblastname = resultset.getString("lastname").toLowerCase(); // assign result to string
				String dbUsername = resultset.getString("username"); // assign result to string

				// if all database records match return true
				if (firstname.equals(dbfirstname) && lastname.equals(dblastname) && username.equals(dbUsername)) {

					connection.close(); // close connection
					statement.close(); // close prepared statement
					resultset.close(); // close result set
					return true; // database query completed
				}
			}
		}
		connection.close(); // close connection
		statement.close(); // close prepared statement
		resultset.close(); // close result set
		return false; // database query not completed
	}

	/**
	 * method changes password for user in database
	 * 
	 * @param username: entered user name
	 * @param password: encrypted password
	 * @return boolean: true / false
	 * @throws SQLException: database access error
	 */
	public boolean changePassword(String username, String password) throws SQLException {

		Connection connection = connect(); // get database connection

		if (connection != null) { // database connection established

			String sql = "UPDATE accounts SET password=? WHERE username=?"; // set qeury string

			statement = connection.prepareStatement(sql); // set precompiled sql string
			statement.setString(1, password); // assign parameter to sql string
			statement.setString(2, User.getUsername()); // assign parameter to sql string
			statement.execute(); // execute sql statement

		}
		connection.close(); // close connection
		statement.close(); // close prepared statement
		return false; // database query completed
	}

	/**
	 * method checks if new password matches database password
	 * 
	 * @param password: encrypted password
	 * @return boolean: true / false
	 * @throws SQLException
	 */
	public boolean passwordExists(String password) throws SQLException {

		Connection connection = connect(); // get database connection

		if (connection != null) { // database connection established

			String sql = "SELECT password FROM accounts WHERE username=?"; // set qeury string

			statement = connection.prepareStatement(sql); // set precompiled sql string
			statement.setString(1, User.getUsername()); // assign parameter to sql string
			resultset = statement.executeQuery(); // execute sql statement

			// loop through resultset
			while (resultset.next()) {

				// tests if password in database is a match
				if (password.equals(resultset.getString("password"))) {
					connection.close(); // close connection
					statement.close(); // close prepared statement
					resultset.close(); // close result set
					return true; // database query completed password exists
				}
			}
		}
		connection.close(); // close connection
		statement.close(); // close prepared statement
		resultset.close(); // close result set
		return false; // database query not completed
	}

	/**
	 * method gets users first name from databae
	 * 
	 * @param username: entered user name
	 * @return String: name
	 * @throws SQLException: database access error
	 */
	public String getFirstName(String username) throws SQLException {

		Connection connection = connect(); // get database connection

		if (connection != null) { // database connection established

			String sql = "SELECT firstname FROM accounts WHERE username=?"; // set qeury string

			statement = connection.prepareStatement(sql); // set precompiled sql string
			statement.setString(1, username); // assign parameter to sql string
			resultset = statement.executeQuery(); // execute sql statement

			// loop through resultset
			while (resultset.next()) {
				String name = resultset.getString("firstname");
				connection.close(); // close connection
				statement.close(); // close prepared statement
				resultset.close(); // close result set
				return name; // return current users first name
			}
		}
		connection.close(); // close connection
		statement.close(); // close prepared statement
		resultset.close(); // close result set
		return ""; // return empty string
	}

	/**
	 * method updates users first name in database
	 * 
	 * @param username
	 * @param firstname
	 * @return
	 * @throws SQLException
	 */
	public boolean updateFirstName(String username, String firstname) throws SQLException {

		try {
			Connection connection = connect(); // get database connection

			if (connection != null) { // database connection established

				String sql = "UPDATE accounts SET firstname=? WHERE username=?"; // set qeury string

				statement = connection.prepareStatement(sql); // set precompiled sql string
				statement.setString(1, firstname); // assign parameter to sql string
				statement.setString(2, username); // assign parameter to sql string
				statement.execute(); // execute sql statement

			}
			connection.close(); // close connection
			statement.close(); // close prepared statement
			return true; // database query completed

		} catch (Exception e) {
			System.out.println("Database error");
			connection.close(); // close connection
			statement.close(); // close prepared statement
			return false; // database query not completed
		}

	}

	/**
	 * method gets users last name from database
	 * 
	 * @param username: entered user name
	 * @return
	 * @throws SQLException: database access error
	 */
	public String getLastName(String username) throws SQLException {

		Connection connection = connect(); // get database connection

		if (connection != null) { // database connection established

			String sql = "SELECT lastname FROM accounts WHERE username=?"; // set qeury string

			statement = connection.prepareStatement(sql); // set precompiled sql string
			statement.setString(1, username); // assign parameter to sql string
			resultset = statement.executeQuery(); // execute sql statement

			// loop through resultset
			while (resultset.next()) {
				String name = resultset.getString("lastname");
				connection.close(); // close connection
				statement.close(); // close prepared statement
				resultset.close(); // close result set
				return name; // return current users lastname
			}
		}
		connection.close(); // close connection
		statement.close(); // close prepared statement
		resultset.close(); // close result set
		return ""; // return empty string
	}

	/**
	 * method updates the first name of current user
	 * 
	 * @param username
	 * @param firstname
	 * @return
	 * @throws SQLException
	 */
	public boolean updateLastName(String username, String lastname) throws SQLException {

		try {
			Connection connection = connect(); // get database connection

			if (connection != null) { // database connection established

				String sql = "UPDATE accounts SET lastname=? WHERE username=?"; // set qeury string

				statement = connection.prepareStatement(sql); // set precompiled sql string
				statement.setString(1, lastname); // assign parameter to sql string
				statement.setString(2, username); // assign parameter to sql string
				statement.execute(); // execute sql statement

			}
			connection.close(); // close connection
			statement.close(); // close prepared statement
			return true; // database query completed

		} catch (Exception e) {
			System.out.println("Database error");
			connection.close(); // close connection
			statement.close(); // close prepared statement
			return false; // database query not completed
		}

	}

	/**
	 * method gets the first and last name from database for current user and
	 * returns them as a joined string
	 * 
	 * @param username: entered user name
	 * @return
	 * @throws SQLException: database access error
	 */
	public String getFullName(String username) throws SQLException {

		String firstname = getFirstName(username).toLowerCase(); // get user first name and make lower case
		firstname = firstname.substring(0, 1).toUpperCase() + firstname.substring(1).toLowerCase(); // capitalize first
																									// character

		String lastname = getLastName(username).toLowerCase(); // get user last name and make lower case // get user
																// first name and make lower case
		lastname = lastname.substring(0, 1).toUpperCase() + lastname.substring(1).toLowerCase(); // capitalize first
																									// character

		return firstname + " " + lastname; // return users full name as a string value
	}

	/**
	 * method createRecord: creates a new user in the database
	 * 
	 * @param username:          entered user name
	 * @param date:              either current date or user entered date
	 * @param time:              current time
	 * @param weight:            persons weight in k.g
	 * @param temperature:       persons temperature reading
	 * @param lowBloodPressure:  persons low blood pressure reading
	 * @param highBloodPressure: persons high blood pressure reading
	 * @param notes:             entered notes
	 * @return boolean: true / false
	 * @throws SQLException: database access error
	 */
	public boolean createRecord(String username, String date, String time, String weight, String temperature,
			String lowBloodPressure, String highBloodPressure, String notes) throws SQLException {

		Connection connection = connect(); // get database connection

		if (connection != null) { // database connection established

			String sql = "INSERT INTO records (username, date, time, weight, temperature, lowBloodPressure, highBloodPressure, notes)VALUES(?,?,?,?,?,?,?,?)"; // set
																																								// qeury
																																								// string

			// Connection conn = connect();
			PreparedStatement ps = connection.prepareStatement(sql); // set precompiled sql string
			ps.setString(1, username); // assign parameter to sql string
			ps.setString(2, date); // assign parameter to sql string
			ps.setString(3, time); // assign parameter to sql string
			ps.setString(4, weight); // assign parameter to sql string
			ps.setString(5, temperature); // assign parameter to sql string
			ps.setString(6, lowBloodPressure); // assign parameter to sql string
			ps.setString(7, highBloodPressure); // assign parameter to sql string
			ps.setString(8, notes); // assign parameter to sql string
			ps.executeUpdate(); // execute sql statement
			ps.close();

			connection.close(); // close connection
			statement.close(); // close prepared statement
			resultset.close(); // close result set
			return true; // database query completed
		}
		// connection.close();
		statement.close();
		resultset.close();
		return false; // database query not completed
	}

	/**
	 * method updateRecord updates record in database
	 * 
	 * @param date:              either current date or user entered date
	 * @param time:              current time
	 * @param weight:            persons weight in k.g
	 * @param temperature:       persons temperature reading
	 * @param lowBloodPressure:  persons low blood pressure reading
	 * @param highBloodPressure: persons high blood pressure reading
	 * @param notes:             entered notes
	 * @param username:          entered user name
	 * @param rowid:             record row id in database
	 * @return boolean: true / false
	 * @throws SQLException:
	 */
	public boolean updateRecord(String date, String time, String weight, String temperature, String lowBloodPressure,
			String highBloodPressure, String notes, String username, String rowid) throws SQLException {

		Connection connection = connect(); // get database connection

		if (connection != null) { // database connection established

			String sql = "UPDATE records SET date=?, time=?,weight=?, temperature=?,lowBloodPressure=?,highBloodPressure=?,notes=? WHERE username=? and ROWID=?";

			statement = connection.prepareStatement(sql); // set precompiled sql string
			statement.setString(1, date); // assign parameter to sql string
			statement.setString(2, time); // assign parameter to sql string
			statement.setString(3, weight); // assign parameter to sql string
			statement.setString(4, temperature); // assign parameter to sql string
			statement.setString(5, lowBloodPressure); // assign parameter to sql string
			statement.setString(6, highBloodPressure); // assign parameter to sql string
			statement.setString(7, notes); // assign parameter to sql string
			statement.setString(8, username); // assign parameter to sql string
			statement.setString(9, rowid); // assign parameter to sql string
			statement.execute(); // execute sql statement
			statement.close();
			return true; // database query completed
		}
		statement.close();
		return false; // database query not completed
	}

	/**
	 * method deletes record from database for current user
	 * 
	 * @param username: entered user name
	 * @return boolean: true / false
	 * @throws SQLException: database access error
	 */
	public boolean deleteRecord(String username, String rowid) throws SQLException {

		Connection connection = connect(); // get database connection

		if (connection != null) { // database connection established

			String sql = "DELETE FROM records WHERE username=? AND ROWID=?"; // set precompiled sql string

			statement = connection.prepareStatement(sql); // set precompiled sql string
			statement.setString(1, username); // assign parameter to sql string
			statement.setString(2, rowid); // assign parameter to sql string
			statement.execute(); // execute sql statement
			connection.close(); // close connection
			statement.close(); // close prepared statement
			return true; // database query completed
		}
		statement.close(); // close prepared statement
		return false; // database query not completed
	}

	/**
	 * getRecords takes in an empty observable list and loads the data from database
	 * 
	 * @param username: entered user name
	 * @param list:     observable list
	 * @return list: observable list
	 * @throws SQLException: database access error
	 */
	public ObservableList<Record> getRecords(String username, ObservableList<Record> list) throws SQLException {

		list.clear(); // empty list

		Connection connection = connect(); // get database connection

		if (connection != null) { // database connection established

			String sql = "SELECT rowid, * FROM records WHERE username=?"; // set precompiled sql string

			statement = connection.prepareStatement(sql); // set precompiled sql string
			statement.setString(1, username); // assign parameter to sql string

			resultset = statement.executeQuery(); // execute sql statement
			ResultSetMetaData metadata = resultset.getMetaData(); // get information about types and properties of
																	// columns of table

			int columnsNumber = metadata.getColumnCount(); // set length of table

			String rowid = null; //
			String date = null; // current date
			String time = null; // current time
			String weight = null; // users weight kg
			String temp = null; // users body temperatur
			String lowBlood = null; // users low blood pressure
			String highBlood = null; // users high blood pressure
			String note = null; // user notes

			// loop through query result
			while (resultset.next()) {

				// loop through columns
				for (int i = 1; i <= columnsNumber; i++) {

					if (i > 0) { // start at column 1

						String columnValue = resultset.getString(i); // get column string value

						switch (i) { // test value
						case 1:
							rowid = columnValue; // assign string value
							break;
						case 3:
							date = columnValue;// assign string value
							break;
						case 4:
							time = columnValue;// assign string value
							break;
						case 5:
							weight = columnValue;// assign string value
							break;
						case 6:
							temp = columnValue;// assign string value
							break;
						case 7:
							lowBlood = columnValue;// assign string value
							break;
						case 8:
							highBlood = columnValue;// assign string value
							break;
						case 9:
							note = columnValue;// assign string value
							break;
						}
					}
				}
				// add new record to list
				list.add(new Record(rowid, date, time, weight, temp, lowBlood, highBlood, note));
			}
		}
		connection.close(); // close connection
		statement.close(); // close prepared statement
		resultset.close(); // close result set
		return list; // return updated list
	}

	/**
	 * method updates image to database as a blob
	 * 
	 * @param username:    current username
	 * @param imageString: image blob
	 * @return boolean: true/false
	 * @throws SQLException: database access error
	 */
	public boolean updateImage(String username, String imageString) throws SQLException {
		try {
			Connection connection = connect(); // get database connection

			if (connection != null) { // database connection established

				String sql = "UPDATE accounts SET picture=? WHERE username=?"; // set precompiled sql string

				statement = connection.prepareStatement(sql); // set precompiled sql string
				statement.setString(1, imageString); // assign parameter to sql string
				statement.setString(2, username); // assign parameter to sql string
				statement.execute(); // execute sql statement
			}
			connection.close(); // close connection
			statement.close(); // close prepared statement
			return true; // database query completed

		} catch (Exception e) {
			System.out.println("Database error");
			connection.close(); // close connection
			statement.close(); // close prepared statement
			return false; // database query not completed
		}
	}

	/**
	 *  method gets image blob from database
	 *  
	 * @param username
	 * @return blob
	 * @throws SQLException: database access error
	 */
	public String getImage(String username) throws SQLException {

		Connection connection = connect(); // get database connection

		if (connection != null) { // database connection established

			String sql = "SELECT picture FROM accounts WHERE username=?"; // set precompiled sql string

			statement = connection.prepareStatement(sql); // set precompiled sql string
			statement.setString(1, username); // assign parameter to sql string
			resultset = statement.executeQuery(); // execute sql statement

			// loop through resultset
			while (resultset.next()) {
				
				String picture = resultset.getString("picture"); // get image blob
				
				connection.close(); // close connection
				statement.close(); // close prepared statement
				resultset.close(); // close result set
				return picture; // return image blob
			}
		}
		connection.close(); // close connection
		statement.close(); // close prepared statement
		resultset.close(); // close result set
		return ""; // query not completed
	}
}
