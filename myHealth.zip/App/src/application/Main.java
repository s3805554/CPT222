package application;

//import required java modules
import java.io.IOException;

// import required javafx modules
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.fxml.FXMLLoader;

/**
 * Class is a loader for fxml documents for the javafx application
 * 
 * @author s3805554
 *
 */
public class Main extends Application {

	// assign static variable to Scene class
	private static Scene scene;

	/**
	 * start method starts application
	 */
	@Override
	public void start(Stage stage) throws IOException {
		scene = new Scene(loadFXML("fxml/login")); // set initial scene
		stage.getIcons().add(new Image(getClass().getResourceAsStream("images/smallHeart.png")));// add icon to title
		stage.setTitle("Welcome to MyHealth"); // add title to title area
		stage.setMaximized(true); // maximize window on startup
		stage.centerOnScreen(); // if screen not maximized center screen
		stage.toFront(); // bring application to the front of other applications
		stage.setScene(scene); // load scene
		stage.show(); // show scene on stage
	}

	/**
	 * method setRoot loads fxml document on stage
	 * 
	 * @param fxml: new scene
	 * @throws IOException
	 */
	static void setRoot(String fxml) throws IOException {
		scene.setRoot(loadFXML(fxml)); // loads next scene on stage
	}

	/**
	 * loadFXML loads scene onto current class
	 * 
	 * @param fxml: new scene
	 * @return fxmlLoader: loaded document
	 * @throws IOException
	 */
	private static Parent loadFXML(String fxml) throws IOException {
		FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource(fxml + ".fxml")); // load new scene document
		return fxmlLoader.load(); // returns loaded scene
	}

	/**
	 * launch methed launches application
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		launch();
	}

}