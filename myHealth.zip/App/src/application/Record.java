package application;

/**
 * Class defines a persons record in a database position relevant to the rowid
 * 
 * @author s3805554
 *
 */
public class Record {

	// initialize instance variables
	private String rowid;
	private String date;
	private String time;
	private String weight;
	private String temperature;
	private String lowBloodPressure;
	private String highBloodPressure;
	private String notes;

	/**
	 * class constructor
	 */
	public Record() {
	}

	/**
	 * class constructor
	 * 
	 * @param rowid:             database row number
	 * @param date:              current or entered date
	 * @param time:              current time
	 * @param weight:            persons weight in kg
	 * @param temperature:       persons body temperature reading
	 * @param lowBloodPressure:  persons blood pressure reading
	 * @param highBloodPressure: persons blood pressure reading
	 * @param note:              persons personal note
	 */
	public Record(String rowid, String date, String time, String weight, String temperature, String lowBloodPressure,
			String highBloodPressure, String note) {
		this.rowid = rowid;
		this.date = date;
		this.time = time;
		this.weight = weight;
		this.temperature = temperature;
		this.lowBloodPressure = lowBloodPressure;
		this.highBloodPressure = highBloodPressure;
		this.notes = note;
	}

	/**
	 * method returns record row id nomber
	 * 
	 * @return rowid
	 */
	public String getRowid() {
		return rowid;
	}

	/**
	 * method sets record row id nomber
	 * 
	 * @param rowid
	 */
	public void setRowid(String rowid) {
		this.rowid = rowid;
	}

	/**
	 * method returns record date
	 * 
	 * @return date
	 */
	public String getDate() {
		return date;
	}

	/**
	 * method sets record date
	 * 
	 * @param date
	 */
	public void setDate(String date) {
		this.date = date;
	}

	/**
	 * method sets record time
	 * 
	 * @param time
	 */
	public void setTime(String time) {
		this.time = time;
	}

	/**
	 * method returns record time
	 * 
	 * @return
	 */
	public String getTime() {
		return time;
	}

	/**
	 * method sets persons weight
	 * 
	 * @param weight
	 */
	public void setWeight(String weight) {
		this.weight = weight;
	}

	/**
	 * method returns persons weight
	 * 
	 * @return weight
	 */
	public String getWeight() {
		return weight;
	}

	/**
	 * method sets persons body temperature
	 * 
	 * @param temperature
	 */
	public void setTemperature(String temperature) {
		this.temperature = temperature;
	}

	/**
	 * method returns persons body temperature
	 * 
	 * @return temperature
	 */
	public String getTemperature() {
		return temperature;
	}

	/**
	 * method sets persons low blood pressure reading
	 * 
	 * @param lowBloodPressure
	 */
	public void setLowBloodPressure(String lowBloodPressure) {
		this.lowBloodPressure = lowBloodPressure;
	}

	/**
	 * method returns persons low blood pressure reading
	 * 
	 * @return lowBloodPressure
	 */
	public String getLowBloodPressure() {
		return lowBloodPressure;
	}

	/**
	 * method sets persons high blood pressure reading
	 * 
	 * @param highBloodPressure
	 */
	public void setHighBloodPressure(String highBloodPressure) {
		this.highBloodPressure = highBloodPressure;
	}

	/**
	 * method returns persons high blood pressure reading
	 * 
	 * @return highBloodPressure
	 */
	public String getHighBloodPressure() {
		return highBloodPressure;
	}

	/**
	 * method sets persons notes
	 * 
	 * @param notes
	 */
	public void setNotes(String notes) {
		this.notes = notes;
	}

	/**
	 * method returns persons notes
	 * 
	 * @return notes
	 */
	public String getNotes() {
		return notes;
	}

}
