package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.regex.Pattern;
import javafx.beans.value.ObservableNumberValue;
import javafx.beans.value.ObservableStringValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.TextAlignment;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * Main controller for myHealth application after user has logged in.
 * 
 * @author s3805554
 *
 */
public class MainController implements Initializable {
 
	// javafx scene Button declarations
	@FXML
	private Button button1; // main button bar top
	@FXML
	private Button button2; // main button bar top
	@FXML
	private Button button3; // main button bar top
	@FXML
	private Button button4; // main button bar top
	@FXML
	private Button button5; // main button bar top
	@FXML
	private Button button6; // main button bar top
	@FXML
	private Button submitButton; // submit records
	@FXML
	private Button updateButton; // update changes
	@FXML
	private Button deleteButton; // delete record
	@FXML
	private Button cancelButton; // cancel current action
	@FXML
	private Button nameUpdateButton; // update persons first and last name
	@FXML
	private Button imageUpdateButton; // update user image

	// javafx scene label declaration
	@FXML
	private Label username; // current users username
	@FXML
	private Label dateMessage; // used for primary message through scenes
	@FXML
	private Label weightMessage; // used if input empty or blank

	// javafx scene image declaration
	@FXML
	private ImageView userlogo; // users logo image

	// javafx scene input field declaration
	@FXML
	private TextField temperature; // persons body temperature input
	@FXML
	private TextField dateInput; // current date input
	@FXML
	private TextField weightInput; // persons weight input
	@FXML
	private TextField temperatureInput; // persons body temperature input
	@FXML
	private TextField lowBloodPressureInput; // persons blood pressure reading input
	@FXML
	private TextField highBloodPressureInput; // persons blood pressure reading input
	@FXML
	private TextField notesInput; // personanl nots input
	@FXML
	private TextField fname; // persons first name input
	@FXML
	private TextField lname; // persons last name input
	@FXML
	private TextField filePath; // selected file path input
	@FXML
	private TextField fileName; // selected filename input
	// @FXML
	// private TextField fnameIn; // first name
	// @FXML
	// private TextField lnameIn; // last name

	// javafx scene tableview chart declaration
	@FXML
	private TableView<Record> table; // table view table
	@FXML
	private TableColumn<Record, String> rowid; // row identification number
	@FXML
	private TableColumn<Record, String> low; // low blood pressure
	@FXML
	private TableColumn<Record, String> high; // high blood pressure
	@FXML
	private TableColumn<Record, String> date; // date of year
	@FXML
	private TableColumn<Record, String> notes; // text note
	@FXML
	private TableColumn<Record, String> temp; // temperature
	@FXML
	private TableColumn<Record, String> weight; // weight in kg

	// class instance declarations
	DBController db = new DBController(); // database control class
	User user = new User(); // user class

	// create monitored lists for live updating
	ObservableList<Record> list = FXCollections.observableArrayList();
	ObservableStringValue fullName; // user name on banner
	ObservableNumberValue themeType; // user color theme

	/**
	 * method initialize update data on changes
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		try { // get get fullname from database - and set label on banner
			username.setText(db.getFullName(User.getUsername()));
		} catch (SQLException e) {
			e.printStackTrace();
		}

		try { // update table data
			updateTable(); // update table after change
		} catch (SQLException e) {
			e.printStackTrace();
		}

		// update table data from record class
		rowid.setCellValueFactory(new PropertyValueFactory<Record, String>("rowid"));
		date.setCellValueFactory(new PropertyValueFactory<Record, String>("date"));
		weight.setCellValueFactory(new PropertyValueFactory<Record, String>("weight"));
		temp.setCellValueFactory(new PropertyValueFactory<Record, String>("temperature"));
		low.setCellValueFactory(new PropertyValueFactory<Record, String>("lowBloodPressure"));
		high.setCellValueFactory(new PropertyValueFactory<Record, String>("highBloodPressure"));
		notes.setCellValueFactory(new PropertyValueFactory<Record, String>("notes"));
		table.setItems(list);

		// autload current date into text area
		dateInput.setText(getDate());

	}

	/**
	 * method gets data from database into list (Observable list)
	 * 
	 * @throws SQLException
	 */
	private void updateTable() throws SQLException {
		list = db.getRecords(application.User.getUsername(), list);
	}

	/**
	 * Javafx button1Action changes scene based on button label
	 * 
	 * @param event - javafx action event
	 * @throws IOException
	 */
	@FXML
	private void button1Action(ActionEvent event) throws IOException {

		// get current label and test against conditions
		if (button1.getText().equals("LOGOUT")) {
			Main.setRoot("fxml/login"); // load scene

		} else { // load main application scene
			Main.setRoot("fxml/main"); // load scene
		}
	}

	/**
	 * Javafx button2Action changes scene based on button label
	 * 
	 * @param event - javafx action event
	 * @throws IOException
	 */
	@FXML
	private void button2Action(ActionEvent event) throws IOException {

		// get current label and test against conditions
		if (button2.getText().equals("CREATE")) {
			Main.setRoot("fxml/main-records-create"); // load scene

		} else if (button2.getText().equals("EDIT")) {
			Main.setRoot("fxml/main-records-edit"); // load scene

		} else {
			Main.setRoot("fxml/main-records"); // load scene
		}
	}

	/**
	 * Javafx button3Action changes scene based on button label
	 * 
	 * @param event - javafx action event
	 * @throws IOException
	 */
	@FXML
	private void button3Action(ActionEvent event) throws IOException {

		// get current label and test against conditions
		if (button3.getText().equals("ACCOUNT")) {
			Main.setRoot("fxml/main-account"); // load scene

		} else {
			Main.setRoot("fxml/main-records-delete"); // load scene
		}
	}

	/**
	 * Javafx button4Action changes scene based on button label
	 * 
	 * @param event - javafx action event
	 * @throws IOException
	 */
	@FXML
	private void button4Action(ActionEvent event) throws IOException {

		// get current label and test against conditions
		if (button4.getText().equals("ABOUT")) {
			Main.setRoot("fxml/main-about"); // load scene

		} else {
			Main.setRoot("fxml/main-records-edit"); // load scene
		}
	}

	/**
	 * Javafx button5Action changes scene based on button label
	 * 
	 * @param event - javafx action event
	 * @throws IOException
	 */
	@FXML
	private void button5Action(ActionEvent event) throws IOException {

		// get current label and test against conditions
		if (button5.getText().equals("EXPORT")) {
			Main.setRoot("fxml/main-records-export"); // load scene
		}
	}

	/**
	 * 
	 * @param event - javafx action event
	 * @throws IOException
	 */
	@FXML
	private void button6Action(ActionEvent event) throws IOException {

		// get current label and test against conditions
		if (button6.getText().equals("VIEW")) {
			Main.setRoot("fxml/main-records"); // load scene
		}
	}

	/**
	 * method extracts current time
	 * 
	 * @return string value i.e. 12:30AM
	 */
	private String getTime() {
		Date currentDate = new Date(); // get current date string
		SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm:a"); // get current date string
		String time = timeFormat.format(currentDate); // get formatted time as string
		return time; // return string time
	}

	/**
	 * method extracts current date
	 * 
	 * @return string value i.e. 01/05/2023
	 */
	private String getDate() {
		Date currentDate = new Date(); // get current date string
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy"); // get current date string
		String date = dateFormat.format(currentDate); // get formatted date as string
		return date;// return string date
	}

	/**
	 * method gets user entered details and creates a record in the database
	 * 
	 * @param event - javafx action event
	 * @throws SQLException
	 */
	@FXML
	private void createRecord(ActionEvent event) throws SQLException {

		// test conditions before calling database method
		if (!dateInput.getText().isEmpty() && !weightInput.getText().isEmpty()) {

			// call database method
			db.createRecord(User.getUsername(), dateInput.getText(), getTime(), weightInput.getText(),
					temperatureInput.getText(), lowBloodPressureInput.getText(), highBloodPressureInput.getText(),
					notesInput.getText());

			dateMessage.setText(""); // clear message text
			weightMessage.setText(""); // clear message text
			updateTable();// update tabel

			// if date not entered
		} else if (dateInput.getText().isEmpty() && !weightInput.getText().isEmpty()) {

			dateMessage.setText("PLEASE FILL IN"); // send user message
			dateMessage.setTextFill(javafx.scene.paint.Color.RED); // set message color red
			weightMessage.setText(""); // clear user message

			// if weight not entered
		} else if (!dateInput.getText().isEmpty() && weightInput.getText().isEmpty()) {

			weightMessage.setText("PLEASE FILL IN"); // send user message
			weightMessage.setTextFill(javafx.scene.paint.Color.RED); // set message color red
			dateMessage.setText(""); // clear user message

			// // if date and weight input empty send user message
		} else if (dateInput.getText().isEmpty() && weightInput.getText().isEmpty()) {

			dateMessage.setText("PLEASE FILL IN"); // send user message
			dateMessage.setTextFill(javafx.scene.paint.Color.RED); // set message color red
			weightMessage.setText("PLEASE FILL IN"); // send user message
			weightMessage.setTextFill(javafx.scene.paint.Color.RED); // set message color red

		} else {

			dateMessage.setText(""); // clear user message
			weightMessage.setText(""); // clear user message
		}

		dateInput.setText(getDate()); // clear input data after table updated
		weightInput.clear(); // clear input data after table updated
		temperatureInput.clear(); // clear input data after table updated
		lowBloodPressureInput.clear(); // clear input data after table updated
		highBloodPressureInput.clear(); // clear input data after table updated
		notesInput.clear(); // clear input data after table updated
	}

	// declare table row id variable
	private String rowId = null;

	/**
	 * method checks details and gets validation prior to calling delete record
	 * method
	 * 
	 * @param event - javafx action event
	 */
	@FXML
	private void deleteControl(ActionEvent event) throws IOException {
		try { // check if record has been selected
			if (rowId != null) {

				dateMessage.setText(""); // clear user message

				// if button label = DELETE change to VALIDATE and change button color
				if (deleteButton.getText().equals("DELETE")) {
					deleteButton.setText(" VALIDATE"); // change button label
					deleteButton.setStyle("-fx-background-color: #53d769;"); // change button color
					dateMessage.setTextFill(javafx.scene.paint.Color.RED); // set message color red
					dateMessage.setTextAlignment(TextAlignment.CENTER); // position message

				} else {
					deleteRecord(); // call delete record method
				}

				// row id is NULL
			} else {
				dateMessage.setText("<-- Please click on a row"); // send user message
				dateMessage.setTextAlignment(TextAlignment.LEFT); // set message color red
				dateMessage.setTextFill(javafx.scene.paint.Color.RED); // position message
			}
		} catch (Exception e) {
			dateMessage.setText("Create a new record"); // send user message
		}
	}

	/**
	 * @param event - javafx action event cancels record deletion process
	 * 
	 * @throws IOException
	 */
	@FXML
	private void cancelDelete(ActionEvent event) throws IOException {
		Main.setRoot("fxml/main-records-delete"); // reload load scene
	}

	/**
	 * event - javafx action event cancels record deletion process
	 * 
	 * @throws SQLException
	 */
	@FXML
	private void deleteRecord() throws SQLException {

		if (rowid != null) { // if row id selected
			deleteButton.setText("DELETE"); // change button text
			deleteButton.setStyle("-fx-background-color: #27476E;"); // change button color
			db.deleteRecord(User.getUsername(), rowId); // call database method deleting record
			updateTable(); // update table data
		}
	}

	/**
	 * method checks details and gets validation prior to calling update record
	 * method
	 * 
	 * @param event - javafx action event
	 */

	@FXML
	private void updateControl(ActionEvent event) throws IOException {
		try {
			if (rowId != null) { // if record selected

				dateMessage.setText(""); // clear message

				if (updateButton.getText().equals("UPDATE")) {

					updateButton.setText(" VALIDATE"); // change button label
					updateButton.setStyle("-fx-background-color: #53d769;"); // change button color
					dateMessage.setTextFill(javafx.scene.paint.Color.RED); // set message color
					dateMessage.setTextAlignment(TextAlignment.CENTER); // set message position

				} else {
					updateRecord(); // update record after update completed
				}

			} else { // no record seleced
				dateMessage.setText("<-- Please click on a row");
				dateMessage.setTextFill(javafx.scene.paint.Color.RED); // set message color
				dateMessage.setTextAlignment(TextAlignment.LEFT); // set message position
			}

		} catch (Exception e) {
			dateMessage.setText("re-enter details"); // send user message
		}
	}

	/**
	 * method recalls screen to clear and cancel process
	 * 
	 * @param event - javafx action event
	 * @throws IOException
	 */
	@FXML
	private void cancelUpdate(ActionEvent event) throws IOException {
		Main.setRoot("fxml/main-records-edit"); // reload load scene
	}

	/**
	 * method updates database record after edit
	 * 
	 * @throws SQLException: database access error
	 * @throws IOException:
	 */
	@FXML
	private void updateRecord() throws SQLException {

		if (rowid != null) { // if table row selected

			db.updateRecord(dateInput.getText(), getTime(), weightInput.getText(), temperatureInput.getText(),
					lowBloodPressureInput.getText(), highBloodPressureInput.getText(), notesInput.getText(),
					User.getUsername(), rowId); // call database method - update record in database

			updateButton.setText("UPDATE"); // change button label
			updateButton.setStyle("-fx-background-color: #27476E;"); // change button color
			updateTable();

			// clear input boxes after update
			dateInput.clear();
			weightInput.clear();
			temperatureInput.clear();
			lowBloodPressureInput.clear();
			highBloodPressureInput.clear();
			notesInput.clear();

		}
	}

	/**
	 * method recalls scene cancelling export process
	 * 
	 * @param event: javafx action event
	 * @throws IOException: page not found when loading
	 */
	@FXML
	private void exportRecordCancel(ActionEvent event) throws IOException {
		Main.setRoot("fxml/main-records-export"); // reload load scene

	}

	/**
	 * 
	 * @param event: javafx action event
	 * @throws IOException:          method call error
	 * @throws InterruptedException: method call error
	 */
	@FXML
	private void exportRecordControl(ActionEvent event) throws InterruptedException, IOException {

		if (filePath.getText().isEmpty() || fileName.getText().isEmpty() || filePath.getText().isBlank()
				|| fileName.getText().isBlank()) {
			dateMessage.setText("PLEASE FILL IN FILE DETAILS");

		} else {
			exportRecords();
		}
	}

	/**
	 * export record corrects directory string
	 * 
	 * @throws IOException:          method call error
	 * @throws InterruptedException: method call error
	 */
	private void exportRecords() throws IOException, InterruptedException {

		String filepath = filePath.getText(); // get textfield information

		String separator = "\\"; // set string split charater set
		String[] strings = filepath.replaceAll(Pattern.quote(separator), "\\\\").split("\\\\"); // replace \ with \\
																								// characters

		String path = ""; // assign variable for loop
		for (String string : strings) { // loop through list
			path = path + string + "\\\\"; // add backslash where needed
		}
		path = path + fileName.getText() + ".csv"; // add .csv to end of new string

		File csvFile = new File(path); // create new csv file
		PrintWriter out = new PrintWriter(csvFile); // prepare print writer for csv input

		out.print("date,time,weight,temperature,highBloodPressure,lowBloodPressure,notes\n"); // add titles to csv

		for (Record record : list) { // loop through records and add details to csv fils
			out.println(record.getDate() + "," + record.getTime() + "," + record.getWeight() + ","
					+ record.getTemperature() + "," + record.getHighBloodPressure() + "," + record.getLowBloodPressure()
					+ "," + record.getNotes());
		}
		out.close(); // close csv file

		filePath.clear(); // clear textfield data
		fileName.clear(); // clear textfield data

		dateMessage.setText("FILE EXPORT COMPLETED"); // send user message
	}

	/**
	 * method gets directory location and adds location to the text field
	 * 
	 * @param javafx action event
	 */
	@FXML
	private void chooseFileLocation(ActionEvent event) {

		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow(); // get current stage information

		final DirectoryChooser directory = new DirectoryChooser(); // initialize directory method
		File filelocation = directory.showDialog(stage); // open directory screne

		if (filelocation != null) { // directory selected
			filePath.setText(String.valueOf(filelocation)); // add text in textfield
		}
	}

	/**
	 * method updates users first and last name in database
	 * 
	 * @param javafx action event
	 * @throws SQLException: database access error
	 * @throws IOException:  class call error
	 */
	@FXML
	private void updateName(ActionEvent event) throws IOException, SQLException {

		// if details not filled in
		if (fname.getText().isEmpty() || lname.getText().isEmpty() || fname.getText().isBlank()
				|| lname.getText().isBlank()) {

			dateMessage.setText("PLEASE FILL IN FIRST AND LAST NAME"); // send user message

		} else { // details filled in

			// test against button label
			if (nameUpdateButton.getText().equals("UPDATE")) {

				nameUpdateButton.setText("VALIDATE"); // change button label
				nameUpdateButton.setStyle("-fx-background-color: #53d769;"); // change button color

			} else {
				db.updateFirstName(User.getUsername(), fname.getText()); // access database method to update name
				db.updateLastName(User.getUsername(), lname.getText()); // access database method to update name
				nameUpdateButton.setText("UPDATE"); // change button label
				Main.setRoot("fxml/main-account"); // reload load scene
			}
		}
	}

	/**
	 * method cancels name update process
	 * 
	 * @param javafx action event
	 * @throws IOException:
	 */
	@FXML
	private void cancelUpdateName(ActionEvent event) throws IOException {
		Main.setRoot("fxml/main-account"); // reload load scene
	}

	/**
	 * method gets file location
	 * 
	 * @param javafx action event
	 * @throws IOException: file not found error
	 */
	@FXML
	private void chooseImage(ActionEvent event) throws IOException {

		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow(); // get current stage information

		FileChooser filechooser = new FileChooser(); // initialize directory method
		File file = filechooser.showOpenDialog(stage); // open directory screen

		if (filechooser != null) { // directory selected
			filePath.setText(String.valueOf(file)); // add text in textfield
		}

	}

	/**
	 * 
	 * @param javafx action event
	 * @throws SQLException: database access error
	 * @throws IOException:  file not found error
	 */
	@FXML
	private void importImage(ActionEvent event) throws IOException, SQLException {

		if (filePath.getText() != null) { // textfield data still exists
			String filepath = filePath.getText(); // assign textfield information to string

			String separator = "\\"; // assign split seperator character
			String[] str_arr = filepath.replaceAll(Pattern.quote(separator), "\\\\").split("\\\\"); // split string

			String path = ""; // assisgn loop variable
			for (String s : str_arr) { // replace characted \ with \\
				path = path + s + "\\\\";
			}

			db.updateImage(User.getUsername(), encodeToString(path)); // add converted string to databse
		}
	}

	/**
	 * method gets image and converts to blob
	 * 
	 * @param filePath path to image
	 * @return returns blob string
	 */
	public static String encodeToString(String filePath) {
		String originalInput = filePath; // image file path
		String encodedString = Base64.getEncoder().encodeToString(originalInput.getBytes()); // convert string
		return encodedString; // return converted image
	}

	/**
	 * method gets the table row that has been clicked and gets row information
	 * 
	 * @param javafx action event
	 */
	@FXML
	private void rowClicked(MouseEvent event) {

		if (list.size() > 0) { // check list has data
			dateMessage.setText(""); // clear any text from area
			Record recordSelected = table.getSelectionModel().getSelectedItem();

			if (recordSelected != null) {
				// get data data from columns in selected table view row
				rowId = String.valueOf(recordSelected.getRowid());
				dateInput.setText(String.valueOf(recordSelected.getDate()));
				weightInput.setText(String.valueOf(recordSelected.getWeight()));
				temperatureInput.setText(String.valueOf(recordSelected.getTemperature()));
				lowBloodPressureInput.setText(String.valueOf(recordSelected.getLowBloodPressure()));
				highBloodPressureInput.setText(String.valueOf(recordSelected.getHighBloodPressure()));
				notesInput.setText(String.valueOf(recordSelected.getNotes()));
			}
		}
	}

}