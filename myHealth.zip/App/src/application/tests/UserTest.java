package application.tests;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import application.User;

class UserTest {
	User user = new User();
	
	
	@Test
	final void testGetFirstname() {
		User.setFirstname("Jon");
		assertEquals("Jon", User.getFirstname());
	}

	@Test
	final void testSetFirstname() {
		User.setFirstname("Jamie");
		assertEquals("Jamie", User.getFirstname());
	}
 
	@Test
	final void testGetLastname() {
		User.setLastname("Snow");
		assertEquals("Snow", User.getLastname());
	}

	@Test
	final void testSetLastname() {
		User.setLastname("Lanister");
		assertEquals("Lanister", User.getLastname());
	}

	@Test
	final void testGetUsername() {
		User.setUsername("Jon Snow");
		assertEquals("Jon Snow", User.getUsername());
	}

	@Test
	final void testSetUsername() {
		User.setUsername("Jamie Lanister");
		assertEquals("Jamie Lanister", User.getUsername());
	}


}
