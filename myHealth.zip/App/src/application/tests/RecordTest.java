/**
 * 
 */
package application.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import application.Record;

/**
 * @author pip_d
 *
 */
class RecordTest {
	
	
	@Test
	final void testRecord() {
			Record record = new Record("1", "01/01/2023", "12:30AM", "75.6", "36", "80", "120", "This is a note");
			assertEquals("1", record.getRowid());
	}
	
	
	/**
	 * Test method for {@link application.Record#getRowid()}.
	 */
	@Test
	final void testGetRowid() {
		Record record = new Record();
		record.setRowid("2");
		assertEquals("2", record.getRowid());
	}

	/**
	 * Test method for {@link application.Record#setDate(java.lang.String)}.
	 */
	@Test
	final void testSetDate() {
		Record record = new Record();
		record.setDate("12/12/2022");
		assertEquals("12/12/2022", record.getDate());
	}

	/**
	 * Test method for {@link application.Record#setTime(java.lang.String)}.
	 */
	@Test
	final void testSetTime() {
		Record record = new Record();
		record.setTime("02:45PM");
		assertEquals("02:45PM", record.getTime());
	}

	/**
	 * Test method for {@link application.Record#setWeight(java.lang.String)}.
	 */
	@Test
	final void testSetWeight() {
		Record record = new Record();
		record.setWeight("92.5");
		assertEquals("92.5", record.getWeight());
	}

	/**
	 * Test method for {@link application.Record#setTemperature(java.lang.String)}.
	 */
	@Test
	final void testSetTemperature() {
		Record record = new Record();
		record.setTemperature("34.0");
		assertEquals("34.0", record.getTemperature());
	}

	/**
	 * Test method for {@link application.Record#setLowBloodPressure(java.lang.String)}.
	 */
	@Test
	final void testSetLowBloodPressure() {
		Record record = new Record();
		record.setLowBloodPressure("80");
		assertEquals("80", record.getLowBloodPressure());
	}

	/**
	 * Test method for {@link application.Record#setHighBloodPressure(java.lang.String)}.
	 */
	@Test
	final void testSetHighBloodPressure() {
		Record record = new Record();
		record.setHighBloodPressure("120");
		assertEquals("120", record.getHighBloodPressure());
	}

	/**
	 * Test method for {@link application.Record#setRowid(java.lang.String)}.
	 */
	@Test
	final void testSetRowid() {
		Record record = new Record();
		record.setTime("1");
		assertEquals("1", record.getTime());
	}

	/**
	 * Test method for {@link application.Record#getDate()}.
	 */
	@Test
	final void testGetDate() {
		Record record = new Record();
		record.setTime("12/12/2023");
		assertEquals("12/12/2023", record.getTime());
	}

	/**
	 * Test method for {@link application.Record#getTime()}.
	 */
	@Test
	final void testGetTime() {
		Record record = new Record();
		record.setTime("12:30AM");
		assertEquals("12:30AM", record.getTime());
	}

	/**
	 * Test method for {@link application.Record#getWeight()}.
	 */
	@Test
	final void testGetWeight() {
		Record record = new Record();
		record.setTemperature("80");
		assertEquals("80", record.getTemperature());
	}

	/**
	 * Test method for {@link application.Record#getTemperature()}.
	 */
	@Test
	final void testGetTemperature() {
		Record record = new Record();
		record.setTemperature("36");
		assertEquals("36", record.getTemperature());
	}

	/**
	 * Test method for {@link application.Record#getLowBloodPressure()}.
	 */
	@Test
	final void testGetLowBloodPressure() {
		Record record = new Record();
		record.setLowBloodPressure("80");
		assertEquals("80", record.getLowBloodPressure());
	}

	/**
	 * Test method for {@link application.Record#getHighBloodPressure()}.
	 */
	@Test
	final void testGetHighBloodPressure() {
		Record record = new Record();
		record.setHighBloodPressure("120");
		assertEquals("120", record.getHighBloodPressure());
	}

	/**
	 * Test method for {@link application.Record#getNotes()}.
	 */
	@Test
	final void testGetNotes() {
		Record record = new Record();
		record.setNotes("This is a note");
		assertEquals("This is a note", record.getNotes());
	}

	/**
	 * Test method for {@link application.Record#setNotes(java.lang.String)}.
	 */
	@Test
	final void testSetNotes() {
		Record record = new Record();
		record.setNotes("This is another note");
		assertEquals("This is another note", record.getNotes());
	}


}
