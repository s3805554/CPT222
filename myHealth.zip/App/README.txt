APPLICATION NAME: 

MyHealth

APPLICATION DESCRIPTION:

The MyHealth application is an application the used used to store 
medical information. the information that the application stores 
is:

1) Record date
2) Record time
3) User body weight
4) User body temperature
5) User low blood pressure
6) Users high blood pressure
7) User notes

The MyHealth application gives the user the ability to:

1) Create a record
2) Delete a record
3) Edit a record
4) Export a record
5) Update users first name
6) Update users last name

APPLICATION DEPENDENCIES

Version: JAVA-17
Version: JAVAFX-20
Version: SQLite3

requires javafx.controls;
requires javafx.fxml;
requires javafx.graphics;
requires java.sql;
requires org.xerial.sqlitejdbc;
requires javafx.base;
requires java.desktop;
requires junit;
requires org.junit.jupiter.api;

opens application to javafx.graphics, javafx.fxml, javafx.base, src.tests;

APPLICATION COMILATION 

application can be compiled useing the following command:

javac --module-path "Path to javafx lib folder" --add-modules javafx.controls,javafx.fxml, javafx.base Main.java

DOCUMENTATION - can be found at the following websites

JAVA

https://docs.oracle.com/en/java/javase/17/

JAVA-FX

https://openjfx.io/javadoc/20/

SQLITE

https://www.sqlite.org/docs.html
